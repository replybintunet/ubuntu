# Fix Black Bars on YouTube Output

## What & Why
The current FFmpeg filter chain uses `force_original_aspect_ratio=decrease` + `pad` to fit the source video into the target frame, which fills any leftover space with black. This causes visible black bars/spots on the edges of the YouTube stream. The fix replaces padding with a scale-and-crop approach so the video always fills the entire output frame.

## Done looks like
- No black bars or black edges visible on the YouTube/Facebook stream output
- Video fills the full frame for both mobile (9:16) and desktop (16:9) ratio modes
- No visual distortion (video is cropped to fill, not stretched)
- Overlay filters (logo, text, ticker) continue to work correctly

## Out of scope
- Changes to bitrate, FPS, or quality settings
- Changes to the overlay system itself
- Frontend UI changes

## Steps
1. **Replace pad with crop in the simple (no overlay) video filter** — In `buildFFmpegArgs`, change the `-vf` argument from `scale=W:H:force_original_aspect_ratio=decrease,pad=W:H:(ow-iw)/2:(oh-ih)/2` to `scale=W:H:force_original_aspect_ratio=increase,crop=W:H` so the video scales up to fill then crops the excess instead of padding with black.

2. **Apply the same fix in the filter_complex path (overlay mode)** — Update the `[0:v]` filter in the `filterParts` array (used when logo or text overlays are active) to also use `force_original_aspect_ratio=increase,crop=W:H` instead of `force_original_aspect_ratio=decrease,pad=...`.

## Relevant files
- `server/stream-manager.ts:231-275`
